const GUA64 = {
  "1,1":["乾为天","天时正好，宜一口气把活儿干完，忌嘴上一句「马上就好」"],
  "8,8":["坤为地","地气够稳，宜老老实实吃顿饱的，忌硬撑着节食"],
  "6,4":["水雷屯","开局就卡，宜先来份薯条垫垫，忌空着肚子改需求"],
  "7,6":["山水蒙","脑子没开机，宜问清楚了再动手，忌瞎猜产品想要啥"],
  "6,1":["水天需","还得再等等，宜先来个圆筒，忌催着上线"],
  "1,6":["天水讼","容易抬杠，宜退半步吃口堡，忌在群里跟人对线"],
  "8,6":["地水师","人多事也杂，宜分好工各点各的，忌一锅乱炖"],
  "6,8":["水地比","人缘挺旺，宜拉个人拼个随心配，忌自己闷头吃"],
  "5,1":["风天小畜","攒着点好，宜加个小食不加大，忌一顿点太多"],
  "1,2":["天泽履","步步踩线，宜小心着提交，忌手一抖 force push"],
  "8,1":["地天泰","通泰顺遂，宜照着计划走，忌临时给自己加戏"],
  "1,8":["天地否","气有点堵，宜先搁着别硬推，忌今天硬上线"],
  "1,3":["天火同人","合得来，宜结对子一起干，忌各改各的"],
  "3,1":["火天大有","手气正旺，宜点份好的犒劳自己，忌一个人吃独食"],
  "8,7":["地山谦","低调点好，宜闷声吃堡，忌发圈炫加班"],
  "4,8":["雷地豫","心情不错，宜慢慢吃不着急，忌边吃边改 bug"],
  "2,4":["泽雷随","跟着走就行，宜听安排，忌另开一摊"],
  "7,5":["山风蛊","旧账要清，宜先收拾烂摊子，忌再堆新需求"],
  "8,2":["地泽临","适合靠近点，宜当面聊两句，忌在文档里打太极"],
  "5,8":["风地观","先看着别急，宜摸清底细，忌抢着表态"],
  "3,4":["火雷噬嗑","有硬骨头，宜先啃最难的，忌拖到下班"],
  "7,3":["山火贲","适合包装，宜把 demo 弄漂亮点，忌只剩个壳"],
  "7,8":["山地剥","有点漏气，宜收着点，忌大改特改"],
  "8,4":["地雷复","缓过来了，宜早睡补觉，忌熬夜硬扛"],
  "1,4":["天雷无妄","别乱来，宜守规矩，忌顺手改别人的代码"],
  "7,1":["山天大畜","劲攒足了，宜蓄着待发，忌现在就 all in"],
  "7,4":["山雷颐","该补了，宜正经吃一顿，忌拿咖啡当饭"],
  "2,5":["泽风大过","有点过头，宜适可而止，忌一口气点三份"],
  "6,6":["坎为水","坑有点多，宜稳着走，忌硬闯"],
  "3,3":["离为火","状态在线，宜多输出，忌光说不动手"],
  "2,7":["泽山咸","容易来电，宜真诚点，忌端着架子"],
  "4,5":["雷风恒","贵在坚持，宜按节奏来，忌干两天停三天"],
  "1,7":["天山遯","该撤就撤，宜早点下班，忌死磕到底"],
  "4,1":["雷天大壮","气势够足，宜趁热打铁，忌用力过猛"],
  "3,8":["火地晋","往上升，宜主动争取，忌等着被发现"],
  "8,3":["地火明夷","光被遮住，宜低调养着，忌抢风头"],
  "5,3":["风火家人","适合收拾，宜整理下工位，忌管别人闲事"],
  "3,2":["火泽睽","有点拧巴，宜求同存异，忌非要分个对错"],
  "6,7":["水山蹇","路不好走，宜绕一绕，忌硬顶"],
  "4,6":["雷水解","结开了，宜把拖着的事办掉，忌继续攒"],
  "7,2":["山泽损","该减了，宜做减法，忌什么都想要"],
  "5,4":["风雷益","有进益，宜顺手帮人一把，忌独占好处"],
  "2,1":["泽天夬","该断了，宜果断砍需求，忌犹犹豫豫"],
  "1,5":["天风姤","容易撞上，宜留个心眼，忌什么局都去"],
  "2,8":["泽地萃","人聚齐了，宜组个饭局，忌各吃各的"],
  "8,5":["地风升","慢慢往上，宜一步一步来，忌想一步登天"],
  "2,6":["泽水困","有点困住，宜先歇口气，忌硬求"],
  "6,5":["水风井","井水不枯，宜复盘沉淀，忌原地打转"],
  "2,3":["泽火革","该换了，宜推倒重来，忌修修补补"],
  "3,5":["火风鼎","要上新，宜换套新方案，忌将就"],
  "4,4":["震为雷","动静不小，宜开个新坑，忌犹豫半天"],
  "7,7":["艮为山","该停了，宜收工走人，忌再改一版"],
  "5,7":["风山渐","慢慢来，宜按部就班，忌跳步骤"],
  "4,2":["雷泽归妹","别急着定，宜先说清楚，忌仓促答应"],
  "4,3":["雷火丰","正当其时，宜趁势干票大的，忌过了头"],
  "3,7":["火山旅","在外奔波，宜就近吃，忌跑太远"],
  "5,5":["巽为风","润物无声，宜小步推进，忌硬刚"],
  "2,2":["兑为泽","和气生财，宜好好说话，忌嘴上不饶人"],
  "5,6":["风水涣","该散了，宜把心结解开，忌憋着"],
  "6,2":["水泽节","有节制，宜量力点单，忌报复性消费"],
  "5,2":["风泽中孚","讲信用，宜说到做到，忌画大饼"],
  "4,7":["雷山小过","小事可为，宜小改小动，忌大动干戈"],
  "6,3":["水火既济","事已成了，宜收尾查一遍，忌松劲"],
  "3,6":["火水未济","还差一点，宜善始善终，忌最后翻车"]
};

const TRIGRAM = {
  1:["乾","金","☰"], 2:["兑","金","☱"], 3:["离","火","☲"], 4:["震","木","☳"],
  5:["巽","木","☴"], 6:["坎","水","☵"], 7:["艮","土","☶"], 8:["坤","土","☷"]
};
const SHENG = {木:"火",火:"土",土:"金",金:"水",水:"木"};
const KE    = {木:"土",土:"水",水:"火",火:"金",金:"木"};
const LANG_WUXING = {
  python:["水","水一样的语言，绕得过坎，最适合写业务逻辑"],
  java:["土","厚土压得住场，企业级系统还得看它"],
  c:["金","最贴机器的语言，硬核但不好伺候"],
  "c++":["金","一把锋利的刀，能砍硬骨头也能砍到自己"],
  go:["木","长得快、并发多，云上跑得欢"],
  rust:["金","炼得很纯的铁，编译器比你还操心"],
  javascript:["火","点着就着，前端全靠它照亮"],
  typescript:["火","给火加了个炉膛，烧得旺还不乱窜"],
  php:["土","老土壤了，半个互联网都长在上面"],
  ruby:["木","柔软好使，写着写着人就开心了"],
  kotlin:["土","安卓的老底子，稳当还爱纳新"],
  swift:["金","快得像风，果家的专属刀"],
  lua:["木","轻得像叶子，嵌进哪儿都能活"]
};
const MING_CARDS = [
  ["巨无霸","双层至尊","两片牛肉夹住你今天的 KPI，吃它就等于给自己盖了个稳章"],
  ["麦辣鸡腿堡","辣度担当","一口下去思路就通了，辣是程序员的强制刷新"],
  ["麦旋风","转圈大师","脑子转不动就先吃口转的，转着转着就想通了"],
  ["薯条","万恶之源","一根接一根，进度和薯条一起见底，记得多要两包番茄酱"],
  ["麦乐鸡","六块正好","不多不少正好六块，够你撑到下一次提交"],
  ["吉士汉堡","一片芝士","朴素但顶饱，今天不折腾，稳稳收工"],
  ["板烧鸡腿堡","不炸主义者","不油炸也香，今天走温和路线，别硬刚"],
  ["圆筒冰淇淋","甜筒收尾","甜的先顶上，苦的放明天，一天才算完整"]
];
/* 今日点单池：五行定池，外应与时辰定轮（改语言/提交/出错/加班都会挪位） */
const ORDER_POOL = {
  "金": ["薯条配麦乐鸡", "麦香鱼配薯条", "麦乐鸡配玉米杯", "薯条配圆筒冰淇淋"],
  "木": ["板烧鸡腿堡配鲜蔬杯", "双吉汉堡配鲜煮咖啡", "麦香鱼配蔬菜色拉", "吉士汉堡配玉米杯"],
  "水": ["麦旋风配可乐", "圆筒冰淇淋配麦乐鸡", "麦乐鸡配冰咖啡", "冰咖啡配吉士汉堡"],
  "火": ["麦辣鸡腿堡", "麦辣鸡翅配可乐", "麦辣鸡腿堡配薯条", "麦辣鸡翅配麦乐鸡"],
  "土": ["巨无霸", "双层吉士汉堡配薯条", "巨无霸配麦乐鸡", "吉士汉堡配薯饼"]
};
const MILD_POOL = ["麦香鱼配薯条", "板烧鸡腿堡配鲜蔬杯", "吉士汉堡配可乐", "玉米杯配麦乐鸡"];
const BREAKFAST_POOL = ["猪柳蛋麦满分配薯饼", "吉士蛋麦满分配热香饼", "猪柳蛋麦满分配豆浆", "薯饼配热豆浆"];
function orderOf(wx, rel, sub, dt){
  const lang = (sub.lang || "").toLowerCase();
  let lh = 0;
  for (let i = 0; i < lang.length; i++) lh += lang.charCodeAt(i);
  const seed = sub.commits * 3 + sub.bugs * 5 + (sub.overtime ? 7 : 0) + lh + dt.getHours();
  const pool = (dt.getHours() >= 5 && dt.getHours() < 10) ? BREAKFAST_POOL
    : (rel === "用克体" ? MILD_POOL
    : (ORDER_POOL[wx] || ORDER_POOL["土"]));
  return pool[((seed % pool.length) + pool.length) % pool.length];
}
const ZHI = ["子","丑","寅","卯","辰","巳","午","未","申","酉","戌","亥"];
const GAN = ["甲","乙","丙","丁","戊","己","庚","辛","壬","癸"];

/* ============================================================
   二、起卦（与 Python 同式）
   ============================================================ */
function shiOf(h){ return ((h + 1) >> 1) % 12 + 1; }   /* 子1 丑2 … 亥12 */

/* 先天数 → 六爻：(数-1) 的三位二进制 B2B1B0，B2 对应初爻、B0 对应上爻，爻象与位取值相反 */
function linesOf(up, down){
  const out = [];
  for (let i = 0; i < 3; i++) out.push(1 - (((down - 1) >> (2 - i)) & 1));
  for (let i = 0; i < 3; i++) out.push(1 - (((up - 1) >> (2 - i)) & 1));
  return out;
}
function trigramOf(l3){
  let bits = 0;
  for (let i = 0; i < 3; i++) bits |= (1 - l3[i]) << (2 - i);
  return bits + 1;
}
function hexHTML(lines, dong){
  let h = "";
  for (let i = 5; i >= 0; i--){
    const yang = lines[i] === 1;
    h += '<i class="yao ' + (yang ? "yang" : "yin") + (dong === i + 1 ? " dong" : "") + '"></i>';
  }
  return h;
}

function guaLabel(up, down){
  if (up === down) return GUA64[up + "," + down][0];
  return TRIGRAM[up][0] + "上" + TRIGRAM[down][0];
}

function meihua(dt){
  const y = dt.getFullYear(), mo = dt.getMonth() + 1, d = dt.getDate(), h = dt.getHours();
  const sum3 = y + mo + d;
  const shi = shiOf(h);
  const sum4 = sum3 + shi;
  const up = (sum3 % 8) || 8;
  const down = (sum4 % 8) || 8;
  const dong = (sum4 % 6) || 6;

  const ben = GUA64[up + "," + down];
  const ls = linesOf(up, down);
  const bl = ls.slice();
  bl[dong - 1] = 1 - bl[dong - 1];
  const down2 = trigramOf(bl.slice(0, 3));
  const up2 = trigramOf(bl.slice(3, 6));
  const bian = GUA64[up2 + "," + down2];

  const huDown = trigramOf([ls[1], ls[2], ls[3]]);
  const huUp = trigramOf([ls[2], ls[3], ls[4]]);
  const hu = GUA64[huUp + "," + huDown];

  return {
    y: y, mo: mo, d: d, h: h, shi: shi, sum3: sum3, sum4: sum4,
    up: up, down: down, up2: up2, down2: down2, huUp: huUp, huDown: huDown, dong: dong,
    benName: ben[0], benVerdict: ben[1], benGua: guaLabel(up, down),
    bianName: bian[0], bianVerdict: bian[1], bianGua: guaLabel(up2, down2),
    huName: hu[0], huVerdict: hu[1], huGua: guaLabel(huUp, huDown),
    benLines: ls, bianLines: bl, huLines: linesOf(huUp, huDown)
  };
}

function tiyong(m){
  const yongIsUpper = m.dong > 3;
  const tiNum = yongIsUpper ? m.down : m.up;
  const yongNum = yongIsUpper ? m.up : m.down;
  const tiEl = TRIGRAM[tiNum][1], yongEl = TRIGRAM[yongNum][1];
  let rel, verdict, luck;
  if (tiEl === yongEl){
    rel = "比和"; verdict = "你俩一个调门，点什么都不会错，也别贪多。"; luck = 72;
  } else if (SHENG[yongEl] === tiEl){
    rel = "用生体"; verdict = "这顿麦是来帮你的，点份好的，别客气。"; luck = 84;
  } else if (SHENG[tiEl] === yongEl){
    rel = "体生用"; verdict = "你会为这顿多费点力气，点小份就够。"; luck = 58;
  } else if (KE[tiEl] === yongEl){
    rel = "体克用"; verdict = "你压得住场面，多点一份也不慌。"; luck = 70;
  } else {
    rel = "用克体"; verdict = "这顿有点压你，清淡为主，别加辣。"; luck = 44;
  }
  return {
    tiName: TRIGRAM[tiNum][0], tiEl: tiEl,
    yongName: TRIGRAM[yongNum][0], yongEl: yongEl,
    yongIsUpper: yongIsUpper, rel: rel, verdict: verdict, luck: luck
  };
}

/* ============================================================
   三、宜忌 · 命卡 · 麦气（与 Python 同式）
   ============================================================ */
function parseVerdict(v){
  const yi = [], ji = [];
  v.split("，").forEach(function(p){
    if (p.charAt(0) === "宜") yi.push(p.slice(1));
    else if (p.charAt(0) === "忌") ji.push(p.slice(1));
  });
  return {yi: yi, ji: ji};
}
function buildYiji(m, ty, sub, wx, dt){
  const b = parseVerdict(m.benVerdict), n = parseVerdict(m.bianVerdict);
  let yi = b.yi.slice(0, 1);
  let ji = b.ji.slice(0, 1);
  n.yi.slice(0, 1).forEach(function(x){ if (yi.indexOf(x) < 0) yi.push(x); });
  n.ji.slice(0, 1).forEach(function(x){ if (ji.indexOf(x) < 0) ji.push(x); });

  if (ty.rel === "用生体"){
    yi.push("拉个人一起点，今天有人替你分担", "点份带肉的，别只喝饮料");
  } else if (ty.rel === "用克体"){
    ji.push("硬着头皮点最辣的", "在店里跟人抢座位");
  } else if (ty.rel === "体生用"){
    ji.push("加钱加大，今天吃不完");
  } else if (ty.rel === "体克用"){
    yi.push("多点一份，今天你压得住");
  }

  if (sub.commits >= 15) yi.push("加个小食，今天提交了 " + sub.commits + " 次");
  if (sub.bugs > 0) ji.push("带着没改完的错去吃饭");
  if (sub.overtime){
    ji.push("加班到店里都快打烊");
    yi.push("用麦乐送，别硬撑到店");
  }

  let order = orderOf(wx, ty.rel, sub, dt);
  yi.push("点一份" + order);
  yi.push("拉个人拼 1+1 随心配，比单点划算");
  if (sub.bugs >= 3) yi.push("来份麦旋风压压惊，别跟自己较劲");
  if (ji.length < 2) ji.push("点完就走，空着手出门");
  if (ji.length < 3) ji.push("边吃边改代码，油手打键盘");

  function uniq(seq){
    const out = [];
    seq.forEach(function(x){ if (x && out.indexOf(x) < 0) out.push(x); });
    return out.slice(0, 6);
  }
  return {yi: uniq(yi), ji: uniq(ji), order: order};
}
function cardIndexOf(sub, dt){
  const seed = sub.commits * 7 + sub.bugs * 13 + (sub.overtime ? 5 : 0)
             + dt.getFullYear() * 10000 + (dt.getMonth() + 1) * 100 + dt.getDate() * 10 + dt.getHours();
  return ((seed % MING_CARDS.length) + MING_CARDS.length) % MING_CARDS.length;
}
function calcScore(sub, ty){
  let base = 60 + Math.min(sub.commits, 20) - sub.bugs * 4 - (sub.overtime ? 8 : 0);
  base = Math.max(30, Math.min(96, base));
  const s = Math.round(base * 0.6 + ty.luck * 0.4);
  return Math.max(30, Math.min(96, s));
}
function maiVerdict(score, ty, sub){
  const grades = [
    [82, "上吉", "今天麦气很足，点什么都不会错"],
    [72, "中吉", "今天挺顺，按老规矩点就行"],
    [62, "小吉", "今天不差，稳着来"],
    [50, "平常", "今天不功不过，吃饱最要紧"],
    [0,  "缓一缓", "今天差点意思，清淡为主"]
  ];
  let grade = "平常", headline = "今天一般";
  for (let i = 0; i < grades.length; i++){
    if (score >= grades[i][0]){ grade = grades[i][1]; headline = grades[i][2]; break; }
  }
  let tip;
  if (sub.overtime) tip = "活是干不完的，先吃饭";
  else if (sub.bugs >= 3) tip = "错已经出了，别拿饭赌气";
  else if (sub.bugs > 0) tip = "小错先记着，吃完再改";
  else if (sub.commits >= 15) tip = "今天干得够多，加个甜的犒劳下";
  else tip = "别在工位上凑合，站起来去吃";
  return {grade: grade, headline: headline, oneLine: ty.verdict, tip: tip};
}

/* ══════════════════════════════════════════════════════════════
   五、结果维度（三端同口径，Python 引擎为真源）
   ══════════════════════════════════════════════════════════════ */
const GUA_TAGS = {
  "1,1": ["开足马力", "一次做完", "别嘴硬"],
  "8,8": ["稳住", "吃饱", "别硬撑"],
  "6,4": ["开局卡", "先垫一口", "别空肚改需求"],
  "7,6": ["没开机", "先问清", "别瞎猜"],
  "6,1": ["再等等", "先来口甜的", "别催上线"],
  "1,6": ["易抬杠", "退半步", "别对线"],
  "8,6": ["人多事杂", "分好工", "别一锅炖"],
  "6,8": ["人缘好", "拉个伴", "别闷头吃"],
  "5,1": ["攒着", "小份就够", "别点太多"],
  "1,2": ["踩线", "小心提交", "别手抖"],
  "8,1": ["顺", "按计划", "别加戏"],
  "1,8": ["气堵", "先搁着", "别硬推"],
  "1,3": ["合得来", "结对子", "别各改各的"],
  "3,1": ["手气旺", "点份好的", "别吃独食"],
  "8,7": ["低调", "闷声吃", "别炫加班"],
  "4,8": ["心情好", "慢慢吃", "别边吃边改"],
  "2,4": ["跟着走", "听安排", "别另开摊"],
  "7,5": ["清旧账", "先收摊子", "别堆需求"],
  "8,2": ["靠近点", "当面聊", "别打太极"],
  "5,8": ["先看戏", "摸清底", "别抢表态"],
  "3,4": ["硬骨头", "先啃难的", "别拖到下班"],
  "7,3": ["好包装", "弄漂亮点", "别只剩壳"],
  "7,8": ["漏气", "收着点", "别大改"],
  "8,4": ["回血", "早睡", "别熬夜"],
  "1,4": ["别乱来", "守规矩", "别动别人代码"],
  "7,1": ["蓄力", "攒着待发", "别 all in"],
  "7,4": ["该补了", "正经吃一顿", "别拿咖啡当饭"],
  "2,5": ["过头", "适可而止", "别点三份"],
  "6,6": ["坑多", "稳着走", "别硬闯"],
  "3,3": ["在线", "多输出", "别光说"],
  "2,7": ["来电", "真诚点", "别端架子"],
  "4,5": ["长跑", "按节奏", "别三天打鱼"],
  "1,7": ["该撤", "早点走", "别死磕"],
  "4,1": ["气势足", "趁热打铁", "别用力过猛"],
  "3,8": ["上升", "主动争取", "别等着被发现"],
  "8,3": ["藏锋芒", "养着", "别抢风头"],
  "5,3": ["收拾", "整工位", "别管闲事"],
  "3,2": ["拧巴", "求同存异", "别争对错"],
  "6,7": ["路难走", "绕一绕", "别硬顶"],
  "4,6": ["解结", "办掉拖着的事", "别继续攒"],
  "7,2": ["做减法", "让一点", "别什么都想要"],
  "5,4": ["有进益", "帮人一把", "别独占"],
  "2,1": ["该断", "砍需求", "别犹豫"],
  "1,5": ["易撞上", "留心眼", "别什么局都去"],
  "2,8": ["人聚齐", "组个饭局", "别各吃各的"],
  "8,5": ["慢慢上", "一步一格", "别想一步登天"],
  "2,6": ["困住", "歇口气", "别硬求"],
  "6,5": ["不枯", "复盘沉淀", "别原地打转"],
  "2,3": ["该换", "推倒重来", "别修补"],
  "3,5": ["上新", "换新方案", "别将就"],
  "4,4": ["动静大", "开个新坑", "别犹豫"],
  "7,7": ["该停", "收工走人", "别再改一版"],
  "5,7": ["慢慢来", "按部就班", "别跳步骤"],
  "4,2": ["别急定", "先问清楚", "别仓促答应"],
  "4,3": ["正当其时", "干票大的", "别过头"],
  "3,7": ["在外跑", "就近吃", "别跑太远"],
  "5,5": ["润物无声", "小步推进", "别硬刚"],
  "2,2": ["和气", "好好说话", "别嘴上不饶人"],
  "5,6": ["该散", "解开结", "别憋着"],
  "6,2": ["有节制", "量力点单", "别报复性消费"],
  "5,2": ["讲信用", "说到做到", "别画饼"],
  "4,7": ["小事可为", "小改小动", "别大动干戈"],
  "6,3": ["已成", "收尾查一遍", "别松劲"],
  "3,6": ["差一点", "善始善终", "别最后翻车"]
};

const TRIGRAM_XIANG = {
  1: ["天", "刚健、往上顶、爱硬碰"],
  2: ["泽", "喜悦、会说话、好交朋友"],
  3: ["火", "明亮、显眼、烧得快"],
  4: ["雷", "动、突然、说来就来"],
  5: ["风", "渗透、顺着走、无孔不入"],
  6: ["水", "险、绕、藏得深"],
  7: ["山", "停、稳、过不去就歇着"],
  8: ["地", "承载、厚、什么都接得住"]
};

const LUCKY_MAP = {
  "金": {
    "color": "白 / 银",
    "num": "4 和 9",
    "dir": "西边",
    "hour": "15–19 点",
    "item": "薯条"
  },
  "木": {
    "color": "青 / 绿",
    "num": "3 和 8",
    "dir": "东边",
    "hour": "7–11 点",
    "item": "板烧鸡腿堡"
  },
  "水": {
    "color": "黑 / 蓝",
    "num": "1 和 6",
    "dir": "北边",
    "hour": "21–1 点",
    "item": "麦旋风"
  },
  "火": {
    "color": "红 / 橙",
    "num": "2 和 7",
    "dir": "南边",
    "hour": "11–15 点",
    "item": "麦辣鸡腿堡"
  },
  "土": {
    "color": "黄 / 棕",
    "num": "5 和 10",
    "dir": "中间（就工位）",
    "hour": "13–17 点",
    "item": "巨无霸"
  }
};

const YAO_POS = {
  "1": [
    "刚起步",
    "今天才开头"
  ],
  "2": [
    "在自己那摊",
    "手上的活最要紧"
  ],
  "3": [
    "进退两难",
    "跨出去回不来，卡在中间"
  ],
  "4": [
    "到了门外",
    "事到临头，得问一句"
  ],
  "5": [
    "坐在主位",
    "今天你能拍板"
  ],
  "6": [
    "走到头了",
    "这一程该收了"
  ]
};

function tagsOf(up, down){
  return GUA_TAGS[up + "," + down] || ["照常", "别折腾", "稳着来"];
}
function luckyOf(wx){
  return LUCKY_MAP[wx] || LUCKY_MAP["土"];
}
function yaoHint(m){
  var pos = m.dong, line = m.benLines[pos - 1];
  var st = YAO_POS[String(pos)];
  return {
    pos: pos, stage: st[0], stage_desc: st[1],
    yin_yang: line === 1 ? "阳" : "阴",
    text: line === 1 ? "阳爻动，宜主动出击，该说就说" : "阴爻动，宜先守着，别抢出头"
  };
}
function profileOf(m){
  var yongUp = m.dong > 3;
  var tiN = yongUp ? m.down : m.up;
  var yoN = yongUp ? m.up : m.down;
  return {
    ti:   { xiang: TRIGRAM_XIANG[tiN][0], nature: TRIGRAM_XIANG[tiN][1] },
    yong: { xiang: TRIGRAM_XIANG[yoN][0], nature: TRIGRAM_XIANG[yoN][1] }
  };
}
function threeThings(yiji, ty, sub){
  var dox = (yiji.yi && yiji.yi[0]) || "照常点一份";
  var dont = (yiji.ji && yiji.ji[0]) || "别折腾";
  var note;
  if (sub.overtime) note = "加班了就点外卖，别硬撑到店里";
  else if (sub.bugs >= 3) note = "今天错出得多，先吃饭再修";
  else if (ty.rel === "用克体") note = "这顿有点压你，清淡为主";
  else if (ty.rel === "用生体") note = "今天有人帮你，别一个人扛";
  else note = "吃完再说，工作和饭都凉不得";
  return { do: dox, dont: dont, note: note };
}


/* ══════════════════════════════════════════════════════════════
   UI 层：单页应用 + 底部切页，首屏只留结论
   ══════════════════════════════════════════════════════════════ */
const $ = function(id){ return document.getElementById(id); };
function setText(id, v){ const el = $(id); if (el) el.textContent = v; }
function pad2(n){ return ("0" + n).slice(-2); }
function dateStr(dt){ return dt.getFullYear() + "-" + pad2(dt.getMonth() + 1) + "-" + pad2(dt.getDate()); }
const WEEK = ["日","一","二","三","四","五","六"];

let NOW = new Date();
let M = null, TY = null;
let REAL = (typeof window.MCD_REAL === "object" && window.MCD_REAL) ? window.MCD_REAL : null;

/* ── Tab 切换 ── */
function goView(v){
  const views = document.querySelectorAll(".view");
  for (let i = 0; i < views.length; i++) views[i].classList.toggle("on", views[i].id === "v-" + v);
  const tabs = document.querySelectorAll(".tab");
  for (let j = 0; j < tabs.length; j++) tabs[j].classList.toggle("on", tabs[j].getAttribute("data-v") === v);
  window.scrollTo(0, 0);
}
function initTabs(){
  const tabs = document.querySelectorAll(".tab");
  for (let i = 0; i < tabs.length; i++){
    tabs[i].addEventListener("click", function(){ goView(this.getAttribute("data-v")); });
  }
  const link = $("srcLine");
  if (link) link.addEventListener("click", function(){ goView("store"); });
}

/* ── 真实数据辅助 ── */
function realOk(){ return !!(REAL && REAL.ok); }
function fmtDist(d){
  if (typeof d !== "number") return "附近";
  return d < 1000 ? d + "<small>米</small>" : (d / 1000).toFixed(1) + "<small>公里</small>";
}
function nearest(){
  const ss = (REAL && REAL.stores) || [];
  if (!ss.length) return null;
  const copy = ss.slice().sort(function(a, b){
    return (a.distance == null ? 1e9 : a.distance) - (b.distance == null ? 1e9 : b.distance);
  });
  return copy[0];
}
function matchCoupon(wish){
  const cs = (REAL && REAL.coupons) || [];
  if (!cs.length) return null;
  const keys = (wish || "").split(/[配和或/、]/).filter(function(k){ return k.length >= 2; });
  for (let i = 0; i < keys.length; i++){
    for (let j = 0; j < cs.length; j++){
      if (cs[j].title.indexOf(keys[i]) >= 0) return cs[j];
    }
  }
  return null;
}
function todayCamp(){
  const cs = (REAL && REAL.campaigns) || [];
  for (let i = 0; i < cs.length; i++) if ((cs[i].tag || "").indexOf("今日") >= 0) return cs[i];
  return cs[0] || null;
}

/* ── 渲染：今日 ── */
function renderToday(){
  const d = NOW;
  setText("tbDate", (d.getMonth() + 1) + "月" + d.getDate() + "日 周" + WEEK[d.getDay()]);
  setText("tbShi", ZHI[M.shi - 1] + "时");

  const lb = subLabel(SUB);
  $("subjLine").innerHTML = lb
    ? "按 <b>" + lb + "</b> 算的 · 改外应"
    : "只按此刻起卦 · 加外应更准";

  const tags = tagsOf(M.up, M.down);
  $("tags").innerHTML = tags.map(function(t){ return '<span class="tag">' + t + "</span>"; }).join("");

  setText("scoreNum", String(SCORE));
  setText("scoreGrade", MV.grade);
  setText("scoreLine", MV.headline);

  /* 点单：五行池轮换（外应一变就换）+ 真实券/门店/活动 */
  const wish = YIJI.order || orderOf(WX, TY.rel, SUB, NOW);
  const cp = matchCoupon(wish);
  /* 主文只放商品名，太长的话人一眼抓不住 */
  setText("orderMain", wish);

  let real = [];
  if (cp){
    real.push("有券：<b>" + cp.title + "</b>" + (cp.status && cp.status.indexOf("可领") < 0 ? " · " + cp.status : ""));
  } else if (realOk() && (REAL.coupons || []).length){
    real.push("今天有 " + REAL.coupons.length + " 张券可领");
  }
  const st = nearest();
  if (st && typeof st.distance === "number"){
    /* 距离与单位之间用不换行空格：390 宽下「173 米」会被折出孤字「米」 */
    real.push("最近那家 <b style=\"white-space:nowrap\">" + (st.distance < 1000 ? st.distance + "\u00A0米" : (st.distance / 1000).toFixed(1) + "\u00A0公里") + "</b>");
  }
  $("orderReal").innerHTML = real.join(" · ");

  const why = [];
  const hr = NOW.getHours();
  if (hr >= 5 && hr < 10) why.push("早餐时段，先来份" + wish);
  else if (TY.rel === "用克体") why.push("这顿压你，吃清淡点：" + wish);
  else why.push(WX + "气当值，该点" + wish);
  if (cp) why.push("刚好有券");
  const cmp = todayCamp();
  if (cmp){
    let ct = (cmp.title || "").trim();
    if (ct.length > 10) ct = ct.slice(0, 10) + "…";
    why.push("「" + ct + "」在进行");
  }
  setText("orderWhy", why.join("，") + "。");

  /* 三件事 */
  const realYiji = realOk() ? buildRealYiji(wish) : null;
  const yi = (realYiji && realYiji.yi.length) ? realYiji.yi : YIJI.yi;
  const ji = (realYiji && realYiji.ji.length) ? realYiji.ji : YIJI.ji;
  setText("tDo", yi[0] || "照常点一份");
  setText("tDont", ji[0] || "别折腾");

  /* 数据来源说明 */
  if (realOk()){
    const tag = REAL.live ? "你自己的数据" : (REAL.demo ? "示例数据" : "麦当劳数据");
    const when = REAL.live ? " · 刚查的 " : " · 抓取于 ";
    $("srcLine").innerHTML = tag
      + (REAL.city ? "（" + REAL.city + "）" : "")
      + when + (REAL.fetched_at || "").slice(5, 16);
  } else {
    $("srcLine").innerHTML = "这会儿没读到数据 · 卦照常算";
  }
}

/* 真实宜忌（与 mcp_client.build_yiji 同口径，浏览器侧实现） */
function buildRealYiji(wish){
  if (!REAL || !REAL.ok) return null;
  const yi = [], ji = [];
  const st = nearest();
  const cp = matchCoupon(wish);
  const cmp = todayCamp();
  if (st && typeof st.distance === "number"){
    const ds = st.distance < 1000 ? st.distance + "\u00A0米" : (st.distance / 1000).toFixed(1) + "\u00A0公里";
    yi.push("去 " + ds + " 那家，走过去不费劲");
  }
  if (cp) yi.push("领「" + cp.title + "」，今天有便宜占");
  if (cmp) yi.push("看一眼「" + cmp.title.slice(0, 12) + "」");
  if (REAL.points && REAL.points.available) yi.push("卡里还有 " + REAL.points.available + " 积分");
  else if (REAL.points && REAL.points.accumulative) yi.push("累计攒了 " + REAL.points.accumulative + " 积分，接着攒");
  ji.push("空着手出门");
  if (st && st.close) ji.push("别等过了 " + st.close + " 再去");
  return { yi: yi, ji: ji };
}

/* ── 渲染：卦象 ── */
function renderGua(){
  $("hexMain").innerHTML = hexHTML(M.benLines, M.dong);
  setText("guaWise", (M.benGua === M.benName ? "纯卦" : M.benGua) + " · " + ZHI[M.shi - 1] + "时起");
  setText("guaName", M.benName);
  setText("guaTag", tagsOf(M.up, M.down).join(" · "));
  setText("guaSay", M.benVerdict);

  /* 动爻 */
  const yh = YAO_HINT;
  $("yaoPos").innerHTML = "第 <em>" + ["一","二","三","四","五","六"][yh.pos - 1] + "</em> 爻动（" + yh.yin_yang + "）";
  setText("yaoStage", yh.stage + " · " + yh.stage_desc);
  setText("yaoText", yh.text);
  setText("yaoNote", "还有一句：" + THREE.note);

  /* 三卦 */
  const rows = [
    ["今日主卦", M.benName, M.benGua, M.benVerdict, M.benLines, M.dong, true],
    ["过程", M.huName, M.huGua, M.huVerdict, M.huLines, 0, false],
    ["收尾", M.bianName, M.bianGua, M.bianVerdict, M.bianLines, 0, false]
  ];
  $("tris").innerHTML = rows.map(function(r){
    return '<div class="tri' + (r[6] ? " now" : "") + '">' +
      '<div class="hex">' + hexHTML(r[4], r[5]) + "</div>" +
      '<div class="tri-b">' +
        '<div class="tri-k">' + r[0] + "</div>" +
        '<div class="tri-n">' + r[1] + "</div>" +
        '<div class="tri-g">' + (r[2] === r[1] ? "纯卦" : r[2]) + "</div>" +
        '<div class="tri-d">' + r[3] + "</div>" +
      "</div></div>";
  }).join("");

  /* 体用 */
  const pf = PROFILE;
  $("tyBox").innerHTML =
    '<div><small>你这边</small><b>' + TY.tiName + "</b><p>" + pf.ti.xiang + " · " + pf.ti.nature + "</p></div>" +
    '<div><small>这顿麦</small><b>' + TY.yongName + "</b><p>" + pf.yong.xiang + " · " + pf.yong.nature + "</p></div>" +
    '<div class="full"><b>' + TY.rel + "</b><p>" + TY.verdict + "</p></div>";

  /* 幸运物 */
  const lk = LUCKY;
  $("lucky").innerHTML = [
    ["幸运色", lk.color], ["幸运数字", lk.num],
    ["好方位", lk.dir], ["好时段", lk.hour]
  ].map(function(x){ return '<div class="lk"><i>' + x[0] + "</i><b>" + x[1] + "</b></div>"; }).join("");

  /* 来由 */
  $("qiTable").innerHTML =
    "<tr><td>起卦时辰</td><td>" + M.y + " 年 " + M.mo + " 月 " + M.d + " 日 " + ZHI[M.shi - 1] + "时</td></tr>" +
    "<tr><td>上卦</td><td>" + (M.sum3 % 8 || 8) + " → " + TRIGRAM[M.up][0] + "（" + TRIGRAM[M.up][1] + "）</td></tr>" +
    "<tr><td>下卦</td><td>" + (M.sum4 % 8 || 8) + " → " + TRIGRAM[M.down][0] + "（" + TRIGRAM[M.down][1] + "）</td></tr>" +
    "<tr><td>动爻</td><td>" + M.sum4 + " ÷ 6 余 " + (M.sum4 % 6 || 6) + " → 第 " + M.dong + " 爻</td></tr>" +
    "<tr><td>本卦</td><td>" + M.benName + "</td></tr>" +
    "<tr><td>互卦</td><td>" + M.huName + "</td></tr>" +
    "<tr><td>变卦</td><td>" + M.bianName + "</td></tr>";
}

/* ── 渲染：门店 ── */
function renderStore(){
  const box = $("storeBox");
  if (!realOk()){
    box.innerHTML = '<div class="empty">这会儿读不到门店数据。<br>' +
      '卦和命卡照常，今天吃啥照样算。</div>';
    $("couponList").innerHTML = '<div class="empty">暂时没有券</div>';
    $("campList").innerHTML = '<div class="empty">暂时没有活动</div>';
    $("pointBox").innerHTML = '<div><small>积分</small><b>—</b></div><div><small>累计</small><b>—</b></div>';
    $("storeFoot").textContent = "数据暂时读不到，过会儿再看";
    return;
  }

  const st = nearest();
  const ss = REAL.stores || [];
  /* 说清楚这是哪座城市、什么时候的数据：别让人以为是自己楼下 */
  $("storeSrc").textContent = "附近门店 · " + (REAL.city || "示例")
    + "（" + (REAL.keyword || "地标") + "一带"
    + (REAL.live ? "，刚查的实时数据）" : "的抓取快照）");
  let html = "";
  if (st){
    html += '<div class="store-hero">' +
      '<div class="sh-dist">' + fmtDist(st.distance) + "</div>" +
      '<div class="sh-name">' + (st.name || "").replace("麦当劳", "").replace("餐厅", "") + "</div>" +
      '<div class="sh-meta">' + (st.address || "") + "</div>" +
      '<div class="sh-tags">' +
        "<span>" + (st.open || "—") + "–" + (st.close || "—") + "</span>" +
        (st.open_now ? "<span>现在开着</span>" : "<span>已打烊</span>") +
        (st.reservation ? "<span>可预约</span>" : "") +
      "</div></div>";
  }
  if (ss.length > 1){
    html += '<div class="list">' + ss.slice(1).map(function(s){
      return '<div class="li"><div class="li-n">' +
        '<div class="li-t">' + (s.name || "").replace("麦当劳", "") + "</div>" +
        '<div class="li-s">' + (s.address || "") + "</div></div>" +
        '<div class="li-d">' + (typeof s.distance === "number" ? (s.distance < 1000 ? s.distance + "\u00A0米" : (s.distance / 1000).toFixed(1) + "\u00A0公里") : "—") + "</div></div>";
    }).join("") + "</div>";
  }
  box.innerHTML = html || '<div class="empty">附近没搜到门店</div>';

  const cps = REAL.coupons || [];
  $("couponList").innerHTML = cps.length ? cps.map(function(c){
    return '<div class="cp"><div class="cp-t">' + c.title + "</div>" +
      '<div class="cp-s">' + (c.status || "可领") + "</div></div>";
  }).join("") : '<div class="empty">这会儿没有可领的券</div>';

  const cms = REAL.campaigns || [];
  $("campList").innerHTML = cms.length ? cms.map(function(c){
    const today = (c.tag || "").indexOf("今日") >= 0;
    return '<div class="camp"><div class="camp-t">' + c.title + "</div>" +
      '<div class="camp-d">' + (c.date || "") + (c.tag ? " · <em>" + c.tag + "</em>" : "") + "</div></div>";
  }).join("") : '<div class="empty">暂无活动</div>';

  const pt = REAL.points || {};
  const masked = pt.available == null && pt.accumulative == null;
  $("pointBox").innerHTML = masked
    ? '<div class="full"><b>这里不显示个人积分</b><p>现在用的是公开数据，不碰你的账号。想看自己的，去「我的」页填一次 Token。</p></div>'
    : "<div><small>可用积分</small><b>" + (pt.available != null ? pt.available : "—") + "</b></div>" +
      "<div><small>累计积分</small><b>" + (pt.accumulative != null ? pt.accumulative : "—") + "</b></div>";

  const when = (REAL.fetched_at || "").slice(0, 16);
  $("storeFoot").textContent = "数据抓取于 " + when + " · 价格与库存以门店为准";
}

/* ── 命卡弹层 ── */
function openCard(){
  const card = MING_CARDS[cardIndexOf(currentSub(), NOW)];
  $("cfHex").innerHTML = hexHTML(M.benLines, 0);
  setText("cfName", M.benName);
  setText("cfStar", card[0] + " · " + card[1]);
  setText("cfBless", card[2]);
  $("sheet").classList.add("on");
}

/* ── 起卦（仪式：六爻自下而上显现） ── */
let asking = false;
function ask(quiet){
  if (asking) return;
  asking = true;
  NOW = new Date();
  M = meihua(NOW);
  TY = tiyong(M);

  const lines = M.benLines;
  let rh = "";
  for (let i = 5; i >= 0; i--) rh += '<i class="yao ' + (lines[i] === 1 ? "yang" : "yin") + '"></i>';
  $("rh").innerHTML = rh;
  $("ritual").classList.add("on");

  const yaoEls = document.querySelectorAll("#rh .yao");
  for (let k = 0; k < yaoEls.length; k++){
    /* 自下而上：DOM 里第 0 个是最上爻，所以要倒着点亮 */
    (function(el, delay){ setTimeout(function(){ el.classList.add("on"); }, delay); })(yaoEls[yaoEls.length - 1 - k], 160 + k * 150);
  }
  setText("ritualT", "起 卦");

  const total = 160 + 6 * 150 + 420;
  setTimeout(function(){
    $("ritual").classList.remove("on");
    compute();
    renderToday();
    renderGua();
    renderStore();
    asking = false;
    if (!quiet && navigator.vibrate) { try{ navigator.vibrate([8, 40, 12]); }catch(e){} }
  }, total);
}

/* ── 计算派生值 ── */
let SUB, WX, SCORE, MV, YIJI, THREE, YAO_HINT, LUCKY, PROFILE;
function currentSub(){
  return {
    lang: $("langSel") ? $("langSel").value : "python",
    commits: $("inCommits") ? (parseInt($("inCommits").value, 10) || 0) : 0,
    bugs: $("inBugs") ? (parseInt($("inBugs").value, 10) || 0) : 0,
    overtime: $("swOt") ? $("swOt").classList.contains("on") : false
  };
}
function compute(){
  SUB = currentSub();
  WX = (LANG_WUXING[SUB.lang] || ["土"])[0];
  TY = tiyong(M);
  SCORE = calcScore(SUB, TY);
  MV = maiVerdict(SCORE, TY, SUB);
  YIJI = buildYiji(M, TY, SUB, WX, NOW);
  THREE = threeThings(YIJI, TY, SUB);
  YAO_HINT = yaoHint(M);
  LUCKY = luckyOf(WX);
  PROFILE = profileOf(M);
}

/* ── 外应：把「这次按什么算的」说清楚 ── */
function subParts(sub){
  const parts = [];
  if (sub.lang && sub.lang !== "python") parts.push(sub.lang);
  if (sub.commits > 0) parts.push(sub.commits + " 次提交");
  if (sub.bugs > 0) parts.push(sub.bugs + " 个错");
  if (sub.overtime) parts.push("加班");
  return parts;
}
function subLabel(sub){
  const parts = subParts(sub);
  return parts.length ? parts.join(" · ") : "";
}

/* ── 外应表单 ── */
function initForm(){
  const langs = Object.keys(LANG_WUXING).filter(function(k){ return k !== "js"; });
  $("langSel").innerHTML = langs.map(function(k){
    return '<option value="' + k + '">' + k + "</option>";
  }).join("");
  $("langSel").value = "python";

  const swallow = $("swOt");
  function toggle(){
    swallow.classList.toggle("on");
    swallow.setAttribute("aria-checked", swallow.classList.contains("on") ? "true" : "false");
  }
  swallow.addEventListener("click", toggle);
  swallow.addEventListener("keydown", function(e){ if (e.key === " " || e.key === "Enter"){ e.preventDefault(); toggle(); } });

  /* 改了就重算：静默重排，不重放起卦仪式 —— 否则用户会以为「选了没反应」 */
  let deb = null;
  function applySoon(announce){
    clearTimeout(deb);
    deb = setTimeout(function(){
      compute();
      renderToday();
      renderGua();
      renderStore();
      const lb = subLabel(SUB);
      if (announce) toast(lb ? "已按 " + lb + " 重算" : "已回到只按此刻起卦", 1600);
    }, 260);
  }
  $("langSel").addEventListener("change", function(){ applySoon(true); });
  $("inCommits").addEventListener("input", function(){ applySoon(false); });
  $("inBugs").addEventListener("input", function(){ applySoon(false); });
  $("inCommits").addEventListener("change", function(){ applySoon(true); });
  $("inBugs").addEventListener("change", function(){ applySoon(true); });
  swallow.addEventListener("click", function(){ applySoon(true); });

  $("subjLine").addEventListener("click", function(){ goView("me"); });

  $("btnRecalc").addEventListener("click", function(){
    START_NOW = null;
    ask();
    goView("today");
  });
}

/* ── 导出 ── */
function safeName(){ return "今日麦占-" + dateStr(NOW); }
/* 小工具容器禁文件下载：走平台能力存相册；无容器能力时提示截图 */
function mtMiniTool(){
  var mt = window.xhs && window.xhs.miniTool;
  return (mt && typeof mt.saveImageToPhotosAlbum === "function") ? mt : null;
}
function savePage(){
  toast("小工具里不用存网页，点「存图」直接进相册");
}
const MAX_SIDE = 16000, MAX_AREA = 4.0e7;
const IMG_CSS = [
  ".topbar,.tabbar,.toast,.sheet,.ritual,.btn,.src,.fold,.vs,.vt{display:none!important}",
  ".view{display:block!important;opacity:1!important;transform:none!important}",
  "#v-gua,#v-store,#v-me{display:none!important}",
  "html,body{background:#F5F0E8!important;padding:0!important;margin:0!important}",
  "main{padding:0 20px!important}"
].join("");
function collectCss(){
  const out = [], sts = document.querySelectorAll("style");
  for (let i = 0; i < sts.length; i++) out.push(sts[i].textContent);
  return out.join("\n").replace(/&/g, "&amp;").replace(/</g, "&lt;");
}
function saveImage(){
  toast("正在拼图，稍等一下…", 12000);
  setTimeout(function(){
    /* 只导出「今日」页，手机上一屏就看得完 */
    const host = $("v-today").cloneNode(true);
    const drops = host.querySelectorAll(".btn,.src");
    for (let i = 0; i < drops.length; i++) drops[i].parentNode.removeChild(drops[i]);
    host.classList.add("on");

    const w = 420, h = Math.max(900, host.offsetHeight + 40);
    const scale = Math.min(2, MAX_SIDE / Math.max(w, h), Math.sqrt(MAX_AREA / (w * h)));
    const W = Math.round(w * scale), H = Math.round(h * scale);
    const svg = '<svg xmlns="http://www.w3.org/2000/svg" width="' + W + '" height="' + H +
      '" viewBox="0 0 ' + w + " " + h + '">' +
      '<foreignObject x="0" y="0" width="' + w + '" height="' + h + '">' +
      '<div xmlns="http://www.w3.org/1999/xhtml" style="width:' + w + 'px;background:#F5F0E8;padding:26px 20px;box-sizing:border-box;font-family:' +
      'Noto Sans SC,PingFang SC,sans-serif">' +
      "<style>" + collectCss() + IMG_CSS + "</style>" + host.innerHTML +
      "</div></foreignObject></svg>";

    const img = new Image();
    img.onload = function(){
      const canvas = document.createElement("canvas");
      canvas.width = W; canvas.height = H;
      const ctx = canvas.getContext("2d");
      ctx.fillStyle = "#F5F0E8";
      ctx.fillRect(0, 0, W, H);
      ctx.drawImage(img, 0, 0, W, H);
      function done(){ toast("存好了，相册里见"); }
      function fail(){ toast("没存上相册，长按页面截图吧"); }
      try {
        const dataUrl = canvas.toDataURL("image/png");
        const mt = mtMiniTool();
        if (mt && typeof mt.writeTempFile === "function"){
          /* 大图先落临时文件，再存相册（平台推荐路径） */
          Promise.resolve(mt.writeTempFile({ data: dataUrl }))
            .then(function(r){
              return Promise.resolve(mt.saveImageToPhotosAlbum({ filePath: r && r.filePath }));
            })
            .then(done, fail);
        } else if (mt) {
          Promise.resolve(mt.saveImageToPhotosAlbum({ filePath: dataUrl })).then(done, fail);
        } else {
          toast("图拼好了，长按或截图保存");
        }
      } catch(e){ toast("图没拼出来，长按页面截图吧"); }
    };
    img.onerror = function(){ toast("图没拼出来，长按页面截图吧"); };
    img.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg);
  }, 60);
}

/* ── Toast ── */
let toastTimer = null;
function toast(msg, ms){
  const el = $("toast");
  el.textContent = msg;
  el.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(function(){ el.classList.remove("show"); }, ms || 2600);
}

/* ── 启动 ── */
/* ── 小工具 → 网页版（容器禁联网 / 禁外链 / 禁剪贴板，只留扫码与带地址两条路） ──
 * 这段留在小工具包里：元素在小工具专有区块中，网页版没有这些 id 时直接跳过。 */
function initWebBridge(){
  const saveBtn = $("btnQrSave");
  const goBtn = $("btnGoWeb");
  if (!saveBtn && !goBtn) return;

  const hint = $("webHint");
  function say(t){ if (hint) hint.textContent = t; }
  function api(){ return (window.xhs && window.xhs.miniTool) || null; }

  if (goBtn){
    goBtn.addEventListener("click", function(){
      goView("me");
      const card = $("webBlock");
      if (card && card.scrollIntoView) card.scrollIntoView({ block: "center" });
    });
  }

  if (saveBtn){
    const qr = $("qrImg");
    saveBtn.addEventListener("click", function(){
      const mt = api();
      if (!mt || typeof mt.saveImageToPhotosAlbum !== "function"){
        say("这个容器不能存图 —— 直接截图这张二维码，用另一台手机扫也能开。");
        return;
      }
      saveBtn.disabled = true;
      mt.saveImageToPhotosAlbum({ filePath: qr.src }).then(function(){
        say("已存进相册。打开微信「扫一扫 → 相册」选它，就能到网页版。");
      }, function(err){
        say("没存成功（" + ((err && err.errMsg) || "未知原因") + "）—— 截图也能扫。");
      }).then(function(){ saveBtn.disabled = false; });
    });
  }

  const cmtBtn = $("btnComment");
  if (cmtBtn){
    const mt = api();
    if (!mt || typeof mt.interactionOpenApi !== "function"){
      cmtBtn.style.display = "none";   /* 9.49 以下没这能力，不摆假按钮 */
    } else {
      cmtBtn.addEventListener("click", function(){
        const urlEl = $("webUrl");
        const url = urlEl ? urlEl.textContent.trim() : "";
        cmtBtn.disabled = true;
        mt.interactionOpenApi({
          payload: {
            action: "post_comment",
            content: "麦门占卜网页版（实时门店 / 券 / 活动）：" + url
          }
        }).then(function(){
          say("评论区已打开，确认发送就把地址留在评论区了。");
        }, function(err){
          say("没打开评论区（" + ((err && err.errMsg) || "未知原因") + "）。");
        }).then(function(){ cmtBtn.disabled = false; });
      });
    }
  }
}

let START_NOW = new Date();
(function boot(){
  initTabs();
  initForm();
  if (typeof initLive === "function") initLive();
  $("btnCard").addEventListener("click", openCard);
  $("sheetClose").addEventListener("click", function(){ $("sheet").classList.remove("on"); });
  $("sheet").addEventListener("click", function(e){ if (e.target === this) this.classList.remove("on"); });
  $("btnSavePage").addEventListener("click", savePage);
  $("btnSaveImg").addEventListener("click", saveImage);
  /* Star 引导：网页直接跳 GitHub；小工具容器禁外链，改为提示项目名 */
  Array.prototype.forEach.call(document.querySelectorAll("[id^=starLink]"), function(el){
    el.addEventListener("click", function(e){
      if (window.xhs && window.xhs.miniTool){
        e.preventDefault();
        toast("GitHub 搜「maimen-zhanbu」点个 Star ⭐");
      }
    });
  });
  $("btnAgain").addEventListener("click", function(){ ask(); });
  ask(true);
  initWebBridge();
  if (typeof BOOT_LIVE === "function") BOOT_LIVE();
})();